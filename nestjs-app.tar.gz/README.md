npm i

docker compose -f "docker-compose.yml" up -d --build

npm run start:dev