export class ErrorDto {
  readonly code: string;
  readonly message: string;
}
