import { PaginationDto } from './pagination.dto';

export class MetaDto {
  readonly pagination?: PaginationDto;
}
